# noteonce 正式版（SwiftUI）— 安裝與開發指南

這個 `noteonce.swiftpm` 是完整的 iOS 正式版專案，功能對齊網頁原型 v1.4：
今日首頁、雙擊縮小選日期（日期卡輪播）、月曆總覽、點年份/日期快速跳轉、
整卡長按拖曳（同日排序＋拖到底部目標區跨日移動）、左滑刪除、點文字編輯、
未完成順延（一鍵確認）、重複記事（每天/每週）、搜尋、明亮/暗黑「紙墨青」配色、
觸覺回饋（真機才有的手感）。資料使用 **SwiftData** 永久保存。

## 需求
- iOS 17 以上（iPhone XS 之後的機型都可以）
- 編譯環境擇一：**Mac（Xcode 15+）** 或 **iPad（Swift Playgrounds 4.5+）**
- Windows 無法編譯 iOS App（這是 Apple 的限制，不是專案的限制）

## 方式一：iPad（最簡單，不用 Mac）
1. 把 `noteonce.swiftpm` 資料夾（解壓縮後）透過 iCloud Drive 或 AirDrop 放到 iPad
2. 打開「Swift Playgrounds」App → 開啟這個專案
3. 按執行 ▶ 就能在 iPad 上跑；也可以直接在裡面改程式碼

## 方式二：Mac（Xcode）
1. 解壓縮後雙擊 `noteonce.swiftpm`（或 Xcode → Open）
2. 選擇模擬器（iPhone 15 等）→ ⌘R 執行
3. 裝到自己的 iPhone：
   - 用線接上 iPhone，Xcode 頂部選你的手機
   - Signing & Capabilities → Team 選你的 Apple ID（免費 Personal Team 即可）
   - ⌘R。第一次要在 iPhone「設定 → 一般 → VPN 與裝置管理」信任開發者
   - 免費帳號簽名 7 天過期，重新 ⌘R 一次即可；加入 Apple Developer Program（US$99/年）則一年有效，並可上 TestFlight / App Store

## 專案結構
| 檔案 | 內容 |
|---|---|
| Package.swift | App 套件定義（名稱、Bundle ID：com.pcedison.noteonce） |
| NoteonceApp.swift | App 進入點、SwiftData 容器 |
| Models.swift | Note／Routine 資料模型＋日期工具 |
| AppState.swift | 畫面狀態、導覽、資料操作（順延/重複/搜尋/統計） |
| Theme.swift | 「紙墨青」配色、動畫曲線、觸覺回饋 |
| RootView.swift | 三層視圖切換（日↔輪播↔月曆）、面板路由、Toast |
| DayView.swift | 日視圖：清單、長按拖曳、拖放目標區、輸入列、順延提示列 |
| NoteRow.swift | 記事卡：勾選、左滑刪除、標籤 |
| CarouselView.swift | 日期卡輪播 |
| MonthView.swift | 月曆總覽 |
| Sheets.swift | 年份選擇、移動記事月曆、搜尋 |
| EditNoteSheet.swift | 編輯：文字/重複設定/移動/刪除 |

## 之後開 iCloud 同步（正式版路線圖）
1. Xcode → Signing & Capabilities → ＋iCloud → 勾 CloudKit，建立 container
2. `NoteonceApp.swift` 的 `.modelContainer(...)` 改為帶 CloudKit 的 `ModelConfiguration`
3. SwiftData 模型已按 CloudKit 相容原則設計（UUID 識別、無強制唯一鍵）

## 注意事項（誠實聲明）
- 這份程式碼是在沒有 Xcode 的環境撰寫的：**尚未經過實際編譯**。
  語法已通過解析器檢查，但第一次在 Xcode/Playgrounds 開啟時，
  可能會有少量需要修正的編譯錯誤（通常是幾行以內）。
  把錯誤訊息貼回對話，我可以直接給修正。
- 長按拖曳與捲動的手勢互動在真機上可能需要微調（門檻值都集中在
  NoteRow.swift 與 DayView.swift，容易調整）。
- 網頁版（https://pcedison.github.io/noteonce-app/）的資料存在瀏覽器，
  與這個 App 的 SwiftData 資料是分開的，不會互通。
