import SwiftUI
import SwiftData

// MARK: - 年份面板

struct YearSheet: View {
    let app: AppState

    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        let thisYear = Day.year(app.today)
        let baseYear = currentBaseYear()
        let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 3)

        VStack(spacing: 4) {
            Text("選擇年份")
                .font(.system(size: 16.5, weight: .bold))
                .foregroundStyle(pal.text)
                .padding(.top, 18)
            Text("點一下直接跳到該年")
                .font(.system(size: 12.5))
                .foregroundStyle(pal.text2)

            ScrollView {
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach((thisYear - 8)...(thisYear + 4), id: \.self) { y in
                        Button {
                            apply(year: y)
                            dismiss()
                        } label: {
                            Text(String(y))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(y == baseYear ? pal.accentInk : pal.text)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(
                                    RoundedRectangle(cornerRadius: 14)
                                        .fill(y == baseYear ? pal.accent : pal.surface2)
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14)
                                        .strokeBorder(y == thisYear && y != baseYear ? pal.accent : Color.clear, lineWidth: 1.6)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
            }
        }
        .presentationBackground(pal.surface)
    }

    private func currentBaseYear() -> Int {
        switch app.mode {
        case .month: return app.monthYear
        case .carousel: return Day.year(app.carouselDay)
        case .day: return Day.year(app.currentDay)
        }
    }

    private func apply(year: Int) {
        switch app.mode {
        case .month:
            app.monthYear = year
        case .carousel:
            let d = app.carouselDay
            app.carouselDay = Day.make(year: year, month: Day.month(d), day: Day.dayNumber(d))
        case .day:
            let d = app.currentDay
            app.goto(Day.make(year: year, month: Day.month(d), day: Day.dayNumber(d)))
        }
        Haptics.light()
    }
}

// MARK: - 移動記事（小月曆）

struct MoveSheet: View {
    let app: AppState
    let note: Note

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    @State private var year: Int = 0
    @State private var month: Int = 0

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        VStack(spacing: 4) {
            Text("移到指定日期")
                .font(.system(size: 16.5, weight: .bold))
                .foregroundStyle(pal.text)
                .padding(.top, 18)
            Text("移動「\(note.text)」到…")
                .font(.system(size: 12.5))
                .foregroundStyle(pal.text2)
                .lineLimit(1)
                .padding(.horizontal, 24)

            HStack {
                navBtn(icon: "chevron.left") { change(-1) }
                Spacer()
                Text("\(String(year))年\(month)月")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(pal.text)
                Spacer()
                navBtn(icon: "chevron.right") { change(1) }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)

            HStack(spacing: 3) {
                ForEach(Day.weekShort, id: \.self) { w in
                    Text(w)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(pal.text2)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)

            ScrollView {
                calendarGrid
                    .padding(.horizontal, 18)
                    .padding(.bottom, 16)
            }
        }
        .presentationBackground(pal.surface)
        .onAppear {
            let d = Day.date(fromKey: note.dayKey)
            year = Day.year(d)
            month = Day.month(d)
        }
    }

    private func navBtn(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(pal.text)
                .frame(width: 42, height: 42)
                .background(RoundedRectangle(cornerRadius: 13).fill(pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func change(_ delta: Int) {
        var m = month + delta
        var y = year
        if m < 1 { m = 12; y -= 1 }
        if m > 12 { m = 1; y += 1 }
        month = m
        year = y
    }

    private var calendarGrid: some View {
        let lead = Day.firstWeekday(year: year, month: month)
        let days = Day.daysInMonth(year: year, month: month)
        let cells: [Int?] = Array(repeating: nil, count: lead) + (1...days).map { Optional($0) }
        let columns = Array(repeating: GridItem(.flexible(), spacing: 3), count: 7)

        return LazyVGrid(columns: columns, spacing: 3) {
            ForEach(Array(cells.enumerated()), id: \.offset) { _, cell in
                if let d = cell {
                    dayCell(d)
                } else {
                    Color.clear.frame(height: 46)
                }
            }
        }
    }

    private func dayCell(_ d: Int) -> some View {
        let date = Day.make(year: year, month: month, day: d)
        let key = Day.key(date)
        let isToday = Day.sameDay(date, app.today)
        let hasNotes = !DataOps.notes(on: key, context).isEmpty

        return Button {
            DataOps.move(note, toKey: key, context)
            app.showToast("已移到 \(Day.mdLabel(date))")
            Haptics.success()
            dismiss()
        } label: {
            VStack(spacing: 4) {
                Text("\(d)")
                    .font(.system(size: 15.5, weight: isToday ? .bold : .regular))
                    .foregroundStyle(isToday ? pal.accent : pal.text)
                Circle()
                    .fill(hasNotes ? pal.accent : Color.clear)
                    .frame(width: 4.5, height: 4.5)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 46)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(isToday ? pal.accent : Color.clear, lineWidth: 1.6)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 搜尋面板

struct SearchSheet: View {
    let app: AppState

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    @State private var query = ""
    @FocusState private var focused: Bool

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        let groups = DataOps.search(query, context)

        VStack(spacing: 0) {
            Text("搜尋記事")
                .font(.system(size: 16.5, weight: .bold))
                .foregroundStyle(pal.text)
                .padding(.top, 18)

            TextField("輸入關鍵字…", text: $query)
                .focused($focused)
                .font(.system(size: 16))
                .padding(.horizontal, 14)
                .frame(height: 48)
                .background(RoundedRectangle(cornerRadius: 14).fill(pal.surface2))
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(pal.accent, lineWidth: 1.4))
                .padding(.horizontal, 18)
                .padding(.top, 10)

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    if query.trimmingCharacters(in: .whitespaces).isEmpty {
                        hint("搜尋所有日期的記事")
                    } else if groups.isEmpty {
                        hint("找不到含「\(query)」的記事")
                    } else {
                        ForEach(groups, id: \.key) { group in
                            Text(dateLabel(group.key))
                                .font(.system(size: 12.5, weight: .bold))
                                .foregroundStyle(pal.text2)
                                .padding(.top, 12)
                            ForEach(group.notes, id: \.uuid) { n in
                                resultRow(n, dayKey: group.key)
                            }
                        }
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 20)
            }
        }
        .presentationBackground(pal.surface)
        .onAppear { focused = true }
    }

    private func hint(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 13))
            .foregroundStyle(pal.text2)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 26)
    }

    private func dateLabel(_ key: String) -> String {
        let d = Day.date(fromKey: key)
        let md = "\(Day.mdLabel(d)) 週\(Day.weekShort[Day.weekdayIndex(d)])"
        return Day.year(d) == Day.year(app.today) ? md : "\(String(Day.year(d)))年" + md
    }

    private func resultRow(_ n: Note, dayKey: String) -> some View {
        Button {
            dismiss()
            app.goto(Day.date(fromKey: dayKey))
            app.mode = .day
            app.flashNoteUUID = n.uuid
        } label: {
            HStack(spacing: 9) {
                Circle()
                    .fill(n.done ? pal.accent : Color.clear)
                    .overlay(Circle().strokeBorder(n.done ? pal.accent : pal.text2, lineWidth: 1.6))
                    .frame(width: 8, height: 8)
                Text(n.text)
                    .font(.system(size: 14.5))
                    .foregroundStyle(n.done ? pal.text2 : pal.text)
                    .strikethrough(n.done, color: pal.text2)
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .background(RoundedRectangle(cornerRadius: 12).fill(pal.surface2))
        }
        .buttonStyle(.plain)
    }
}
