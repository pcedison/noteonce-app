import SwiftUI
import SwiftData

struct DayView: View {
    let app: AppState
    @Binding var themeMode: String

    var body: some View {
        DayContent(dayKey: app.currentKey, app: app, themeMode: $themeMode)
            .id(app.currentKey)   // 換日時整頁重建，重置暫時狀態
    }
}

/// 框架偏好：收集各列與拖放目標區在 "dayspace" 座標系的位置
struct FramePref: PreferenceKey {
    static var defaultValue: [String: CGRect] = [:]
    static func reduce(value: inout [String: CGRect], nextValue: () -> [String: CGRect]) {
        value.merge(nextValue()) { _, new in new }
    }
}

struct DayContent: View {
    let dayKey: String
    let app: AppState
    @Binding var themeMode: String

    @Environment(\.modelContext) private var context
    @Environment(\.colorScheme) private var scheme
    @AppStorage("lastRollAsk") private var lastRollAsk = ""

    @Query private var notes: [Note]

    // 新增輸入
    @State private var inputText = ""
    @FocusState private var inputFocused: Bool

    // 拖曳協調
    @State private var draggingUUID: UUID? = nil
    @State private var dragLocation: CGPoint = .zero
    @State private var frames: [String: CGRect] = [:]
    @State private var localOrder: [UUID] = []
    @State private var hoveredZone: String? = nil

    init(dayKey: String, app: AppState, themeMode: Binding<String>) {
        self.dayKey = dayKey
        self.app = app
        self._themeMode = themeMode
        let pred = #Predicate<Note> { $0.dayKey == dayKey }
        self._notes = Query(filter: pred, sort: [SortDescriptor(\Note.order)])
    }

    private var pal: Palette { Palette.of(scheme) }

    private var displayNotes: [Note] {
        guard draggingUUID != nil, !localOrder.isEmpty else { return notes }
        let map = Dictionary(uniqueKeysWithValues: notes.map { ($0.uuid, $0) })
        return localOrder.compactMap { map[$0] }
    }

    private var draggingNote: Note? {
        guard let id = draggingUUID else { return nil }
        return notes.first { $0.uuid == id }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            VStack(spacing: 0) {
                header
                noteList
            }

            if app.showRollBanner && draggingUUID == nil {
                rollBanner
                    .padding(.horizontal, 14)
                    .padding(.bottom, 82)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            if draggingUUID == nil {
                inputBar
                    .padding(.horizontal, 14)
                    .padding(.bottom, 16)
            } else {
                dropZones
                    .padding(.horizontal, 12)
                    .padding(.bottom, 14)
            }

            ghostLayer
        }
        .coordinateSpace(name: "dayspace")
        .onPreferenceChange(FramePref.self) { frames = $0 }
        .animation(.inkQuick, value: app.showRollBanner)
    }

    // MARK: - 頁首

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 8) {
                Button {
                    app.sheet = .yearPicker
                } label: {
                    HStack(spacing: 5) {
                        Text("\(String(Day.year(app.currentDay)))年")
                        Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold))
                    }
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(pal.text2)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Capsule().fill(pal.surface2))
                }
                .buttonStyle(.plain)

                Spacer()

                if !app.isOnToday {
                    Button {
                        app.goto(app.today)
                    } label: {
                        Text("回到今天")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(pal.accent)
                            .padding(.horizontal, 13)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(pal.accentSoft))
                    }
                    .buttonStyle(.plain)
                }

                Button {
                    themeMode = (scheme == .dark) ? "light" : "dark"
                } label: {
                    Image(systemName: scheme == .dark ? "sun.max" : "moon")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.text2)
                        .frame(width: 36, height: 36)
                        .background(Circle().fill(pal.surface2))
                }
                .buttonStyle(.plain)
            }

            Button {
                app.enterMonth(from: .day)
            } label: {
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    Text(Day.mdLabel(app.currentDay))
                        .font(.system(size: 30, weight: .heavy))
                        .foregroundStyle(pal.text)
                    Text(Day.weekFull[Day.weekdayIndex(app.currentDay)])
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.text2)
                    Image(systemName: "chevron.down")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(pal.text2)
                }
            }
            .buttonStyle(.plain)
            .padding(.top, 4)

            Text(metaLine)
                .font(.system(size: 13))
                .foregroundStyle(pal.text2)
                .padding(.top, 2)
        }
        .padding(.horizontal, 18)
        .padding(.top, 8)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { app.enterCarousel() }
    }

    private var metaLine: String {
        if notes.isEmpty { return " " }
        let done = notes.filter { $0.done }.count
        return "\(notes.count) 則記事 · 已完成 \(done)"
    }

    // MARK: - 清單

    private var noteList: some View {
        ScrollViewReader { proxy in
            noteScroll
                .onChange(of: app.flashNoteUUID) { _, id in
                    guard let id else { return }
                    withAnimation(.inkSpring) { proxy.scrollTo(id, anchor: .center) }
                    Task { @MainActor in
                        try? await Task.sleep(nanoseconds: 1_400_000_000)
                        app.flashNoteUUID = nil
                    }
                }
        }
    }

    private var noteScroll: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                if notes.isEmpty {
                    emptyState.padding(.top, 44)
                }
                ForEach(displayNotes, id: \.uuid) { note in
                    NoteRow(
                        note: NoteDisplay(text: note.text, done: note.done, rolled: note.rolled, isRoutine: note.routineUUID != nil),
                        isDragSource: draggingUUID == note.uuid,
                        isFlashing: app.flashNoteUUID == note.uuid,
                        onToggle: { toggle(note) },
                        onTapText: { app.sheet = .editNote(note) },
                        onDelete: { remove(note) },
                        onLiftChanged: { loc in liftChanged(note, loc) },
                        onLiftEnded: { liftEnded() }
                    )
                    .id(note.uuid)
                    .background(
                        GeometryReader { geo in
                            Color.clear.preference(
                                key: FramePref.self,
                                value: ["row-\(note.uuid.uuidString)": geo.frame(in: .named("dayspace"))]
                            )
                        }
                    )
                }
                Color.clear
                    .frame(height: 160)
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) { app.enterCarousel() }
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle().fill(pal.accentSoft).frame(width: 74, height: 74)
                Image(systemName: "square.and.pencil")
                    .font(.system(size: 26))
                    .foregroundStyle(pal.accent)
            }
            .padding(.bottom, 8)
            Text("這一天還沒有記事")
                .font(.system(size: 15.5, weight: .semibold))
                .foregroundStyle(pal.text)
            Text("用下方輸入列新增第一則，\n或雙擊空白處挑其他日子。")
                .font(.system(size: 13))
                .foregroundStyle(pal.text2)
                .multilineTextAlignment(.center)
                .lineSpacing(3)
        }
        .frame(maxWidth: .infinity)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { app.enterCarousel() }
    }

    // MARK: - 輸入列

    private var inputBar: some View {
        HStack(spacing: 10) {
            Button {
                app.sheet = .search
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(pal.text2)
                    .frame(width: 46, height: 46)
                    .background(Circle().fill(pal.surface))
                    .overlay(Circle().strokeBorder(pal.surface3.opacity(0.6), lineWidth: 1))
            }
            .buttonStyle(.plain)

            TextField("新增記事…", text: $inputText)
                .focused($inputFocused)
                .submitLabel(.done)
                .onSubmit { addNote() }
                .font(.system(size: 16))
                .padding(.horizontal, 18)
                .frame(height: 50)
                .background(Capsule().fill(pal.surface))
                .overlay(Capsule().strokeBorder(inputFocused ? pal.accent : pal.surface3.opacity(0.6), lineWidth: 1))

            Button {
                addNote()
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(pal.accentInk)
                    .frame(width: 50, height: 50)
                    .background(Circle().fill(pal.accent))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 順延提示列

    private var rollBanner: some View {
        HStack(spacing: 9) {
            (Text("過去 ") + Text("\(app.rollDays)").foregroundColor(pal.accent).bold()
             + Text(" 天還有 ") + Text("\(app.rollCount)").foregroundColor(pal.accent).bold()
             + Text(" 則未完成的記事"))
                .font(.system(size: 12.5))
                .foregroundStyle(pal.text)
                .frame(maxWidth: .infinity, alignment: .leading)

            Button {
                let n = DataOps.rollToToday(todayKey: app.todayKey, context)
                lastRollAsk = app.todayKey
                app.showRollBanner = false
                app.showToast("已順延 \(n) 則到今天")
                Haptics.success()
            } label: {
                Text("移到今天")
                    .font(.system(size: 12.5, weight: .bold))
                    .foregroundStyle(pal.accentInk)
                    .padding(.horizontal, 12).padding(.vertical, 9)
                    .background(RoundedRectangle(cornerRadius: 11).fill(pal.accent))
            }
            .buttonStyle(.plain)

            Button {
                lastRollAsk = app.todayKey
                app.showRollBanner = false
            } label: {
                Text("保留")
                    .font(.system(size: 12.5, weight: .bold))
                    .foregroundStyle(pal.text2)
                    .padding(.horizontal, 12).padding(.vertical, 9)
                    .background(RoundedRectangle(cornerRadius: 11).fill(pal.surface2))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(pal.surface)
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(pal.accent, lineWidth: 1.4))
                .shadow(color: Color.black.opacity(0.12), radius: 12, y: 6)
        )
    }

    // MARK: - 拖放目標區

    private var dropZones: some View {
        HStack(spacing: 8) {
            zone(id: "prev", icon: "chevron.left", label: "前一天")
            zone(id: "pick", icon: "calendar", label: "選日期")
            zone(id: "next", icon: "chevron.right", label: "後一天")
        }
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }

    private func zone(id: String, icon: String, label: String) -> some View {
        let hot = hoveredZone == id
        return HStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 11, weight: .bold))
            Text(label).font(.system(size: 12.5, weight: .bold))
        }
        .foregroundStyle(pal.accent)
        .frame(maxWidth: .infinity)
        .frame(height: 62)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(hot ? pal.accentSoft : pal.surface.opacity(0.92))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(pal.accent, style: StrokeStyle(lineWidth: 1.6, dash: hot ? [] : [6, 4]))
                )
        )
        .scaleEffect(hot ? 1.05 : 1)
        .animation(.inkQuick, value: hot)
        .background(
            GeometryReader { geo in
                Color.clear.preference(key: FramePref.self, value: ["zone-\(id)": geo.frame(in: .named("dayspace"))])
            }
        )
    }

    // MARK: - 拖曳浮起殘影

    @ViewBuilder
    private var ghostLayer: some View {
        if let note = draggingNote {
            RowCardContent(note: NoteDisplay(text: note.text, done: note.done, rolled: note.rolled, isRoutine: note.routineUUID != nil))
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(pal.surface)
                        .shadow(color: Color.black.opacity(0.3), radius: 18, y: 10)
                )
                .frame(width: max(100, (frames["row-\(note.uuid.uuidString)"]?.width ?? 340)))
                .scaleEffect(1.03)
                .rotationEffect(.degrees(1))
                .position(dragLocation)
                .allowsHitTesting(false)
                .transition(.opacity)
        }
    }

    // MARK: - 動作

    private func addNote() {
        let t = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        _ = DataOps.addNote(text: t, on: dayKey, context)
        inputText = ""
        inputFocused = true
        Haptics.light()
    }

    private func toggle(_ note: Note) {
        note.done.toggle()
        DataOps.save(context)
    }

    private func remove(_ note: Note) {
        DataOps.delete(note, context)
        app.showToast("已刪除")
    }

    private func liftChanged(_ note: Note, _ loc: CGPoint) {
        if draggingUUID == nil {
            draggingUUID = note.uuid
            localOrder = notes.map { $0.uuid }
        }
        dragLocation = loc

        // 目標區偵測
        var zone: String? = nil
        for id in ["prev", "pick", "next"] {
            if let f = frames["zone-\(id)"], f.contains(loc) {
                zone = id
                break
            }
        }
        if zone != hoveredZone {
            hoveredZone = zone
            if zone != nil { Haptics.light() }
        }

        // 同日排序：依 y 位置調整插入點
        guard zone == nil, let dragID = draggingUUID else { return }
        var others = localOrder.filter { $0 != dragID }
        var insertAt = others.count
        for (i, id) in others.enumerated() {
            if let f = frames["row-\(id.uuidString)"], loc.y < f.midY {
                insertAt = i
                break
            }
        }
        others.insert(dragID, at: insertAt)
        if others != localOrder {
            withAnimation(.inkQuick) { localOrder = others }
        }
    }

    private func liftEnded() {
        guard let dragID = draggingUUID, let note = notes.first(where: { $0.uuid == dragID }) else {
            draggingUUID = nil
            hoveredZone = nil
            return
        }
        let zone = hoveredZone
        withAnimation(.inkQuick) {
            draggingUUID = nil
            hoveredZone = nil
        }
        switch zone {
        case "prev":
            let target = Day.addDays(app.currentDay, -1)
            DataOps.move(note, toKey: Day.key(target), context)
            app.showToast("已移到 \(Day.mdLabel(target))")
        case "next":
            let target = Day.addDays(app.currentDay, 1)
            DataOps.move(note, toKey: Day.key(target), context)
            app.showToast("已移到 \(Day.mdLabel(target))")
        case "pick":
            app.sheet = .moveNote(note)
        default:
            let map = Dictionary(uniqueKeysWithValues: notes.map { ($0.uuid, $0) })
            DataOps.commitOrder(localOrder.compactMap { map[$0] }, context)
        }
        localOrder = []
    }
}
