// swift-tools-version: 5.9

// noteonce — 個人記事 APP
// 此專案為 Swift Playgrounds 相容的 App 套件：
// - iPad：用 Swift Playgrounds 直接開啟即可執行
// - Mac：用 Xcode 開啟 noteonce.swiftpm 即可編譯、裝到 iPhone

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "noteonce",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "noteonce",
            targets: ["AppModule"],
            bundleIdentifier: "com.pcedison.noteonce",
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .calendar),
            accentColor: .presetColor(.teal),
            supportedDeviceFamilies: [
                .phone,
                .pad
            ],
            supportedInterfaceOrientations: [
                .portrait
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ]
)
