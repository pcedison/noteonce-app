import Foundation
import Observation
import SwiftData

// MARK: - 畫面模式與面板

enum ViewMode {
    case day        // 日視圖（首頁，開啟一律今天）
    case carousel   // 雙擊縮小後的日期卡輪播
    case month      // 月曆總覽
}

enum ActiveSheet: Identifiable {
    case yearPicker
    case editNote(Note)
    case search
    case moveNote(Note)

    var id: String {
        switch self {
        case .yearPicker: return "year"
        case .editNote(let n): return "edit-\(n.uuid.uuidString)"
        case .search: return "search"
        case .moveNote(let n): return "move-\(n.uuid.uuidString)"
        }
    }
}

// MARK: - 全域狀態

@Observable
final class AppState {
    var today: Date = Day.startOfToday()
    var currentDay: Date = Day.startOfToday()
    var mode: ViewMode = .day

    // 月曆
    var monthYear: Int = Day.year(Day.startOfToday())
    var monthMonth: Int = Day.month(Day.startOfToday())
    var monthFrom: ViewMode = .day

    // 輪播
    var carouselDay: Date = Day.startOfToday()

    // 面板 / 提示
    var sheet: ActiveSheet? = nil
    var toast: String? = nil
    var flashNoteUUID: UUID? = nil

    // 順延提示列
    var showRollBanner: Bool = false
    var rollCount: Int = 0
    var rollDays: Int = 0

    var todayKey: String { Day.key(today) }
    var currentKey: String { Day.key(currentDay) }
    var isOnToday: Bool { Day.sameDay(currentDay, today) }

    // MARK: 導覽

    func goto(_ date: Date) {
        currentDay = Day.calendar.startOfDay(for: date)
    }

    func enterCarousel() {
        guard mode == .day else { return }
        carouselDay = currentDay
        mode = .carousel
        Haptics.light()
    }

    func exitCarousel(to date: Date) {
        goto(date)
        mode = .day
        Haptics.light()
    }

    func enterMonth(from: ViewMode) {
        monthFrom = from
        let base = (from == .carousel) ? carouselDay : currentDay
        monthYear = Day.year(base)
        monthMonth = Day.month(base)
        mode = .month
        Haptics.light()
    }

    func exitMonth(to date: Date?) {
        if let d = date {
            goto(d)
            mode = .day
        } else {
            mode = (monthFrom == .carousel) ? .carousel : .day
            if mode == .carousel { carouselDay = currentDay }
        }
        Haptics.light()
    }

    func showToast(_ text: String) {
        toast = text
    }

    /// App 回到前景時檢查是否跨日
    func refreshTodayIfNeeded() {
        let now = Day.startOfToday()
        if !Day.sameDay(now, today) {
            today = now
            currentDay = now
            mode = .day
        }
    }
}

// MARK: - 資料操作（集中於此，View 不直接碰查詢細節）

enum DataOps {

    static func notes(on key: String, _ context: ModelContext) -> [Note] {
        let pred = #Predicate<Note> { $0.dayKey == key }
        let desc = FetchDescriptor<Note>(predicate: pred, sortBy: [SortDescriptor(\Note.order)])
        return (try? context.fetch(desc)) ?? []
    }

    static func allNotes(_ context: ModelContext) -> [Note] {
        let desc = FetchDescriptor<Note>(sortBy: [SortDescriptor(\Note.dayKey), SortDescriptor(\Note.order)])
        return (try? context.fetch(desc)) ?? []
    }

    static func allRoutines(_ context: ModelContext) -> [Routine] {
        (try? context.fetch(FetchDescriptor<Routine>())) ?? []
    }

    static func nextOrder(on key: String, _ context: ModelContext) -> Int {
        (notes(on: key, context).map { $0.order }.max() ?? -1) + 1
    }

    @discardableResult
    static func addNote(text: String, on key: String, _ context: ModelContext) -> Note {
        let n = Note(text: text, dayKey: key, order: nextOrder(on: key, context))
        context.insert(n)
        save(context)
        return n
    }

    static func delete(_ note: Note, _ context: ModelContext) {
        context.delete(note)
        save(context)
    }

    static func move(_ note: Note, toKey: String, _ context: ModelContext) {
        guard note.dayKey != toKey else { return }
        note.dayKey = toKey
        note.order = nextOrder(on: toKey, context)
        save(context)
    }

    static func commitOrder(_ ordered: [Note], _ context: ModelContext) {
        for (i, n) in ordered.enumerated() {
            n.order = i
        }
        save(context)
    }

    static func save(_ context: ModelContext) {
        try? context.save()
    }

    // MARK: 重複記事

    static func routineMatches(_ r: Routine, date: Date) -> Bool {
        r.freq == -1 || r.freq == Day.weekdayIndex(date)
    }

    /// 瀏覽某日（今天以後）時，把符合的重複規則實例化成真正的記事
    static func materializeRoutines(for date: Date, today: Date, _ context: ModelContext) {
        let key = Day.key(date)
        guard key >= Day.key(today) else { return }
        let existing = notes(on: key, context)
        for r in allRoutines(context) where routineMatches(r, date: date) {
            if !existing.contains(where: { $0.routineUUID == r.uuid }) {
                let n = Note(text: r.text, dayKey: key, order: nextOrder(on: key, context), routineUUID: r.uuid)
                context.insert(n)
            }
        }
        save(context)
    }

    /// 尚未實例化的重複項（供輪播卡與月曆的預覽/計數）
    static func ghostRoutines(for date: Date, today: Date, _ context: ModelContext) -> [Routine] {
        let key = Day.key(date)
        guard key >= Day.key(today) else { return [] }
        let existing = notes(on: key, context)
        return allRoutines(context).filter { r in
            routineMatches(r, date: date) && !existing.contains(where: { $0.routineUUID == r.uuid })
        }
    }

    // MARK: 順延

    /// 過去日期、未完成、且非重複實例的記事
    static func pendingRollover(todayKey: String, _ context: ModelContext) -> [Note] {
        allNotes(context).filter { $0.dayKey < todayKey && !$0.done && $0.routineUUID == nil }
    }

    static func rollToToday(todayKey: String, _ context: ModelContext) -> Int {
        let items = pendingRollover(todayKey: todayKey, context)
        var order = nextOrder(on: todayKey, context)
        for n in items {
            n.dayKey = todayKey
            n.rolled = true
            n.order = order
            order += 1
        }
        save(context)
        return items.count
    }

    // MARK: 搜尋

    static func search(_ query: String, _ context: ModelContext) -> [(key: String, notes: [Note])] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return [] }
        let hits = allNotes(context).filter { $0.text.lowercased().contains(q) }
        let grouped = Dictionary(grouping: hits, by: { $0.dayKey })
        return grouped.keys.sorted(by: >).map { (key: $0, notes: grouped[$0] ?? []) }
    }

    // MARK: 每日/每月統計

    static func monthStats(year: Int, month: Int, today: Date, _ context: ModelContext) -> [Int: (total: Int, undone: Int)] {
        let prefix = String(format: "%04d-%02d-", year, month)
        var result: [Int: (total: Int, undone: Int)] = [:]
        for n in allNotes(context) where n.dayKey.hasPrefix(prefix) {
            let dayNum = Int(n.dayKey.suffix(2)) ?? 0
            var cur = result[dayNum] ?? (0, 0)
            cur.total += 1
            if !n.done { cur.undone += 1 }
            result[dayNum] = cur
        }
        // 加上尚未實例化的重複項
        let days = Day.daysInMonth(year: year, month: month)
        for d in 1...days {
            let date = Day.make(year: year, month: month, day: d)
            let ghosts = ghostRoutines(for: date, today: today, context).count
            if ghosts > 0 {
                var cur = result[d] ?? (0, 0)
                cur.total += ghosts
                cur.undone += ghosts
                result[d] = cur
            }
        }
        return result
    }
}
