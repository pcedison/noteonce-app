import Foundation
import SwiftData

// MARK: - 資料模型

@Model
final class Note {
    var uuid: UUID
    var text: String
    var done: Bool
    var dayKey: String        // "2026-07-24"
    var order: Int            // 同日排序
    var rolled: Bool          // 是否為順延而來
    var routineUUID: UUID?    // 重複記事規則的實例
    var createdAt: Date

    init(text: String, dayKey: String, order: Int, done: Bool = false, rolled: Bool = false, routineUUID: UUID? = nil) {
        self.uuid = UUID()
        self.text = text
        self.dayKey = dayKey
        self.order = order
        self.done = done
        self.rolled = rolled
        self.routineUUID = routineUUID
        self.createdAt = Date()
    }
}

@Model
final class Routine {
    var uuid: UUID
    var text: String
    var freq: Int             // -1 = 每天；0...6 = 每週（0=週日）

    init(text: String, freq: Int) {
        self.uuid = UUID()
        self.text = text
        self.freq = freq
    }
}

// MARK: - 日期工具（純邏輯）

enum Day {
    static var calendar: Calendar {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = TimeZone.current
        return c
    }

    static let weekFull = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"]
    static let weekShort = ["日", "一", "二", "三", "四", "五", "六"]

    static func startOfToday() -> Date {
        calendar.startOfDay(for: Date())
    }

    static func key(_ date: Date) -> String {
        let c = calendar.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    static func date(fromKey key: String) -> Date {
        let parts = key.split(separator: "-").compactMap { Int($0) }
        guard parts.count == 3 else { return startOfToday() }
        var c = DateComponents()
        c.year = parts[0]
        c.month = parts[1]
        c.day = parts[2]
        return calendar.date(from: c) ?? startOfToday()
    }

    static func addDays(_ date: Date, _ n: Int) -> Date {
        calendar.date(byAdding: .day, value: n, to: date) ?? date
    }

    static func weekdayIndex(_ date: Date) -> Int {
        (calendar.component(.weekday, from: date) - 1)   // 0 = 週日
    }

    static func year(_ date: Date) -> Int { calendar.component(.year, from: date) }
    static func month(_ date: Date) -> Int { calendar.component(.month, from: date) }
    static func dayNumber(_ date: Date) -> Int { calendar.component(.day, from: date) }

    static func daysInMonth(year: Int, month: Int) -> Int {
        var c = DateComponents()
        c.year = year
        c.month = month
        c.day = 1
        guard let d = calendar.date(from: c),
              let range = calendar.range(of: .day, in: .month, for: d) else { return 30 }
        return range.count
    }

    static func firstWeekday(year: Int, month: Int) -> Int {
        var c = DateComponents()
        c.year = year
        c.month = month
        c.day = 1
        guard let d = calendar.date(from: c) else { return 0 }
        return weekdayIndex(d)
    }

    static func make(year: Int, month: Int, day: Int) -> Date {
        var c = DateComponents()
        c.year = year
        c.month = month
        c.day = min(day, daysInMonth(year: year, month: month))
        return calendar.date(from: c) ?? startOfToday()
    }

    /// "7月24日"
    static func mdLabel(_ date: Date) -> String {
        "\(month(date))月\(dayNumber(date))日"
    }

    /// "2026年7月24日"
    static func fullLabel(_ date: Date) -> String {
        "\(year(date))年\(mdLabel(date))"
    }

    static func sameDay(_ a: Date, _ b: Date) -> Bool {
        key(a) == key(b)
    }
}
