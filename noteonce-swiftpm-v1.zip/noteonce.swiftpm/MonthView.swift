import SwiftUI
import SwiftData

/// 月曆總覽：整月格子＋記事圓點，點日開啟、可換月換年
struct MonthView: View {
    let app: AppState

    @Environment(\.modelContext) private var context
    @Environment(\.colorScheme) private var scheme

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        let stats = DataOps.monthStats(year: app.monthYear, month: app.monthMonth, today: app.today, context)

        VStack(spacing: 0) {
            // 年份 chip
            Button {
                app.sheet = .yearPicker
            } label: {
                HStack(spacing: 6) {
                    Text("\(String(app.monthYear))年").font(.system(size: 15.5, weight: .bold))
                    Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold)).foregroundStyle(pal.text2)
                }
                .foregroundStyle(pal.text)
                .padding(.horizontal, 14).padding(.vertical, 9)
                .background(RoundedRectangle(cornerRadius: 12).fill(pal.surface2))
            }
            .buttonStyle(.plain)
            .padding(.top, 14)

            // 月份導覽
            HStack(spacing: 14) {
                navBtn(icon: "chevron.left") { changeMonth(-1) }
                Text("\(app.monthMonth)月")
                    .font(.system(size: 26, weight: .heavy))
                    .foregroundStyle(pal.text)
                    .frame(minWidth: 96)
                navBtn(icon: "chevron.right") { changeMonth(1) }
            }
            .padding(.top, 8)

            // 星期列
            HStack(spacing: 4) {
                ForEach(Day.weekShort, id: \.self) { w in
                    Text(w)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(pal.text2)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 14)
            .padding(.top, 10)

            // 日格
            monthGrid(stats: stats)
                .padding(.horizontal, 12)
                .padding(.top, 4)

            Spacer(minLength: 0)

            HStack(spacing: 12) {
                Button {
                    app.exitMonth(to: nil)
                } label: {
                    Text("返回")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.text)
                        .padding(.horizontal, 20)
                        .frame(height: 44)
                        .background(Capsule().fill(pal.surface2))
                }
                .buttonStyle(.plain)

                Button {
                    app.monthYear = Day.year(app.today)
                    app.monthMonth = Day.month(app.today)
                    Haptics.light()
                } label: {
                    Text("今天")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(pal.accent)
                        .padding(.horizontal, 20)
                        .frame(height: 44)
                        .background(Capsule().fill(pal.accentSoft))
                }
                .buttonStyle(.plain)
            }
            .padding(.bottom, 6)

            Text("點日期開啟該日 · 雙擊空白處返回")
                .font(.system(size: 12))
                .foregroundStyle(pal.text2)
                .padding(.bottom, 18)
        }
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { app.exitMonth(to: nil) }
    }

    private func navBtn(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(pal.text)
                .frame(width: 44, height: 44)
                .background(Circle().fill(pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func changeMonth(_ delta: Int) {
        var m = app.monthMonth + delta
        var y = app.monthYear
        if m < 1 { m = 12; y -= 1 }
        if m > 12 { m = 1; y += 1 }
        app.monthMonth = m
        app.monthYear = y
        Haptics.light()
    }

    private func monthGrid(stats: [Int: (total: Int, undone: Int)]) -> some View {
        let lead = Day.firstWeekday(year: app.monthYear, month: app.monthMonth)
        let days = Day.daysInMonth(year: app.monthYear, month: app.monthMonth)
        let cells: [Int?] = Array(repeating: nil, count: lead) + (1...days).map { Optional($0) }
        let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 7)

        return LazyVGrid(columns: columns, spacing: 4) {
            ForEach(Array(cells.enumerated()), id: \.offset) { _, cell in
                if let d = cell {
                    dayCell(d, stat: stats[d])
                } else {
                    Color.clear.frame(height: 52)
                }
            }
        }
    }

    private func dayCell(_ d: Int, stat: (total: Int, undone: Int)?) -> some View {
        let date = Day.make(year: app.monthYear, month: app.monthMonth, day: d)
        let isToday = Day.sameDay(date, app.today)
        let isCurrent = !isToday && Day.sameDay(date, app.currentDay)
        let total = stat?.total ?? 0
        let undone = stat?.undone ?? 0

        return Button {
            app.exitMonth(to: date)
        } label: {
            VStack(spacing: 5) {
                Text("\(d)")
                    .font(.system(size: 16.5, weight: isToday ? .heavy : .medium))
                    .foregroundStyle(isToday ? pal.accent : pal.text)
                HStack(spacing: 3) {
                    ForEach(0..<min(3, total), id: \.self) { i in
                        Circle()
                            .fill(i < min(3, undone) ? pal.accent : pal.surface3)
                            .frame(width: 4.5, height: 4.5)
                    }
                }
                .frame(height: 5)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(isCurrent ? pal.accentSoft : Color.clear)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .strokeBorder(isToday ? pal.accent : Color.clear, lineWidth: 1.6)
            )
        }
        .buttonStyle(.plain)
    }
}
