import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.colorScheme) private var scheme
    @Environment(\.scenePhase) private var scenePhase

    @State private var app = AppState()

    @AppStorage("themeMode") private var themeMode = "system"   // system / light / dark
    @AppStorage("didSeedWelcome") private var didSeedWelcome = false
    @AppStorage("lastRollAsk") private var lastRollAsk = ""

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        ZStack {
            pal.bg.ignoresSafeArea()

            DayView(app: app, themeMode: $themeMode)
                .scaleEffect(app.mode == .day ? 1.0 : 0.6)
                .opacity(app.mode == .day ? 1 : 0)
                .allowsHitTesting(app.mode == .day)

            CarouselView(app: app)
                .scaleEffect(carouselScale)
                .opacity(app.mode == .carousel ? 1 : 0)
                .allowsHitTesting(app.mode == .carousel)

            MonthView(app: app)
                .scaleEffect(app.mode == .month ? 1.0 : 1.28)
                .opacity(app.mode == .month ? 1 : 0)
                .allowsHitTesting(app.mode == .month)

            toastLayer
        }
        .animation(.inkSpring, value: app.mode)
        .preferredColorScheme(preferredScheme)
        .sheet(item: $app.sheet) { sheet in
            sheetView(sheet)
        }
        .onAppear { bootstrap() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                app.refreshTodayIfNeeded()
                prepareDay()
                checkRollover()
            }
        }
        .onChange(of: app.currentDay) { _, _ in
            prepareDay()
        }
    }

    private var carouselScale: CGFloat {
        switch app.mode {
        case .carousel: return 1.0
        case .day: return 1.3
        case .month: return 0.86
        }
    }

    private var preferredScheme: ColorScheme? {
        switch themeMode {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }

    // MARK: - Toast

    private var toastLayer: some View {
        VStack {
            Spacer()
            if let t = app.toast {
                Text(t)
                    .font(.system(size: 13.5, weight: .semibold))
                    .foregroundStyle(scheme == .dark ? Palette.dark.text : Color.white)
                    .padding(.horizontal, 17)
                    .padding(.vertical, 10)
                    .background(
                        Capsule().fill(scheme == .dark ? Color(hex: 0x2C3038) : Color(hex: 0x282C34).opacity(0.93))
                    )
                    .padding(.bottom, 100)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .task {
                        try? await Task.sleep(nanoseconds: 1_600_000_000)
                        withAnimation(.inkQuick) { app.toast = nil }
                    }
            }
        }
        .animation(.inkQuick, value: app.toast)
        .allowsHitTesting(false)
    }

    // MARK: - Sheet 路由

    @ViewBuilder
    private func sheetView(_ sheet: ActiveSheet) -> some View {
        switch sheet {
        case .yearPicker:
            YearSheet(app: app)
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        case .editNote(let note):
            EditNoteSheet(app: app, note: note)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        case .search:
            SearchSheet(app: app)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        case .moveNote(let note):
            MoveSheet(app: app, note: note)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }

    // MARK: - 啟動流程

    private func bootstrap() {
        if !didSeedWelcome {
            let key = app.todayKey
            _ = DataOps.addNote(text: "歡迎使用 noteonce！長按我可以拖曳排序", on: key, context)
            _ = DataOps.addNote(text: "打勾左邊的圓圈，把我標記完成", on: key, context)
            didSeedWelcome = true
        }
        prepareDay()
        checkRollover()
    }

    /// 進入某一天前：實例化重複記事
    private func prepareDay() {
        DataOps.materializeRoutines(for: app.currentDay, today: app.today, context)
    }

    private func checkRollover() {
        guard lastRollAsk != app.todayKey else {
            app.showRollBanner = false
            return
        }
        let items = DataOps.pendingRollover(todayKey: app.todayKey, context)
        if items.isEmpty {
            app.showRollBanner = false
        } else {
            app.rollCount = items.count
            app.rollDays = Set(items.map { $0.dayKey }).count
            app.showRollBanner = true
        }
    }
}
