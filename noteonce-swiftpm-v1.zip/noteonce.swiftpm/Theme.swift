import SwiftUI
import UIKit

// MARK: - 配色「紙墨青」

struct Palette {
    let bg: Color
    let surface: Color
    let surface2: Color
    let surface3: Color
    let text: Color
    let text2: Color
    let accent: Color
    let accentInk: Color
    let accentSoft: Color
    let danger: Color
    let dangerSoft: Color

    static let light = Palette(
        bg: Color(hex: 0xF5F3EE),
        surface: Color(hex: 0xFFFFFF),
        surface2: Color(hex: 0xECE9E1),
        surface3: Color(hex: 0xDDD9CD),
        text: Color(hex: 0x282C34),
        text2: Color(hex: 0x8D8B82),
        accent: Color(hex: 0x177E71),
        accentInk: Color(hex: 0xFFFFFF),
        accentSoft: Color(hex: 0x177E71).opacity(0.11),
        danger: Color(hex: 0xE5484D),
        dangerSoft: Color(hex: 0xE5484D).opacity(0.12)
    )

    static let dark = Palette(
        bg: Color(hex: 0x0F1114),
        surface: Color(hex: 0x1B1E24),
        surface2: Color(hex: 0x262A31),
        surface3: Color(hex: 0x343943),
        text: Color(hex: 0xEDEEE9),
        text2: Color(hex: 0x9B9EA6),
        accent: Color(hex: 0x3ECFB2),
        accentInk: Color(hex: 0x07251F),
        accentSoft: Color(hex: 0x3ECFB2).opacity(0.14),
        danger: Color(hex: 0xFF6369),
        dangerSoft: Color(hex: 0xFF6369).opacity(0.15)
    )

    static func of(_ scheme: ColorScheme) -> Palette {
        scheme == .dark ? .dark : .light
    }
}

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255.0
        let g = Double((hex >> 8) & 0xFF) / 255.0
        let b = Double(hex & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - 動畫曲線

extension Animation {
    /// 對應原型的 cubic-bezier(.32,.72,.28,1)
    static let inkSpring = Animation.spring(response: 0.38, dampingFraction: 0.86)
    static let inkQuick = Animation.spring(response: 0.25, dampingFraction: 0.8)
}

// MARK: - 常用小元件樣式

struct ChipButtonStyle: ButtonStyle {
    let bg: Color
    let fg: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(fg)
            .background(bg)
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .animation(.inkQuick, value: configuration.isPressed)
    }
}

// MARK: - 觸覺回饋

enum Haptics {
    static func light() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    static func medium() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}
