import SwiftUI
import SwiftData

@main
struct NoteonceApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [Note.self, Routine.self])
        // 未來要開 iCloud 同步：改用自訂 ModelConfiguration 並在
        // Signing & Capabilities 加入 iCloud (CloudKit) 即可。
    }
}
