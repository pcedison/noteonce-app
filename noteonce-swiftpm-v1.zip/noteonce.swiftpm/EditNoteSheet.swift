import SwiftUI
import SwiftData

/// 編輯記事：改文字、設定重複（不重複／每天／每週X）、移到其他日期、刪除
struct EditNoteSheet: View {
    let app: AppState
    let note: Note

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    @State private var text = ""
    @State private var freq: Int? = nil        // nil = 不重複、-1 = 每天、0...6 = 每週

    private var pal: Palette { Palette.of(scheme) }

    private var noteWeekday: Int {
        Day.weekdayIndex(Day.date(fromKey: note.dayKey))
    }

    var body: some View {
        VStack(spacing: 0) {
            Text("編輯記事")
                .font(.system(size: 16.5, weight: .bold))
                .foregroundStyle(pal.text)
                .padding(.top, 18)

            TextField("記事內容", text: $text, axis: .vertical)
                .font(.system(size: 16))
                .lineLimit(3...6)
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14).fill(pal.surface2))
                .foregroundStyle(pal.text)
                .padding(.horizontal, 18)
                .padding(.top, 12)

            // 重複設定
            HStack(spacing: 7) {
                Text("重複")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(pal.text2)
                freqChip(nil, label: "不重複")
                freqChip(-1, label: "每天")
                freqChip(noteWeekday, label: "每週\(Day.weekShort[noteWeekday])")
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)

            HStack(spacing: 10) {
                Button {
                    app.sheet = .moveNote(note)   // 直接切換面板，避免 dismiss 競態
                } label: {
                    Text("移到其他日期")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.accent)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(RoundedRectangle(cornerRadius: 14).fill(pal.accentSoft))
                }
                .buttonStyle(.plain)

                Button {
                    DataOps.delete(note, context)
                    app.showToast("已刪除")
                    dismiss()
                } label: {
                    Text("刪除")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(RoundedRectangle(cornerRadius: 14).fill(pal.dangerSoft))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)

            Button {
                save()
            } label: {
                Text("儲存")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(pal.accentInk)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(RoundedRectangle(cornerRadius: 15).fill(pal.accent))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 18)
            .padding(.top, 10)

            Spacer(minLength: 0)
        }
        .presentationBackground(pal.surface)
        .onAppear {
            text = note.text
            if let rid = note.routineUUID,
               let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                freq = r.freq
            } else {
                freq = nil
            }
        }
    }

    private func freqChip(_ value: Int?, label: String) -> some View {
        let selected = (freq == value)
        return Button {
            freq = value
            Haptics.light()
        } label: {
            Text(label)
                .font(.system(size: 13.5, weight: .semibold))
                .foregroundStyle(selected ? pal.accentInk : pal.text2)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(RoundedRectangle(cornerRadius: 12).fill(selected ? pal.accent : pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func save() {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty {
            note.text = t
        }

        if freq == nil {
            // 取消重複：刪除規則並解除所有實例
            if let rid = note.routineUUID {
                if let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                    context.delete(r)
                }
                for n in DataOps.allNotes(context) where n.routineUUID == rid {
                    n.routineUUID = nil
                }
            }
        } else if let f = freq {
            if let rid = note.routineUUID,
               let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                r.freq = f
                r.text = note.text
            } else {
                let r = Routine(text: note.text, freq: f)
                context.insert(r)
                note.routineUUID = r.uuid
            }
        }

        DataOps.save(context)
        app.showToast("已更新")
        dismiss()
    }
}
