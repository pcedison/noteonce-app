import SwiftUI
import SwiftData

/// 編輯記事：改文字、設定重複（不重複／每天／自訂星期組合）、移到其他日期、刪除
struct EditNoteSheet: View {
    let app: AppState
    let note: Note

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    @State private var text = ""
    @State private var selectedDays: Set<Int> = []   // 0=週日 … 6=週六；空集合＝不重複

    private var pal: Palette { Palette.of(scheme) }
    private let allDays: Set<Int> = [0, 1, 2, 3, 4, 5, 6]

    private var noteWeekday: Int {
        Day.weekdayIndex(Day.date(fromKey: note.dayKey))
    }

    var body: some View {
        VStack(spacing: 0) {
            Text("編輯記事")
                .font(.system(size: 16.5, weight: .bold))
                .foregroundStyle(pal.text)
                .padding(.top, 18)

            TextField("記事內容", text: $text, axis: .vertical)
                .font(.system(size: 16))
                .lineLimit(3...6)
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14).fill(pal.surface2))
                .foregroundStyle(pal.text)
                .padding(.horizontal, 18)
                .padding(.top, 12)

            // 重複設定：不重複／每天／自訂
            HStack(spacing: 7) {
                Text("重複")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(pal.text2)
                freqChip("不重複", selected: selectedDays.isEmpty) {
                    selectedDays = []
                }
                freqChip("每天", selected: selectedDays.count == 7) {
                    selectedDays = allDays
                }
                freqChip("自訂", selected: !selectedDays.isEmpty && selectedDays.count < 7) {
                    if selectedDays.isEmpty || selectedDays.count == 7 {
                        selectedDays = [noteWeekday]
                    }
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)

            // 星期圓鈕（有選任何重複時顯示，可自由勾選組合）
            if !selectedDays.isEmpty {
                HStack(spacing: 8) {
                    ForEach(0..<7, id: \.self) { d in
                        dayToggle(d)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 10)
                .transition(.opacity)
            }

            HStack(spacing: 10) {
                Button {
                    app.sheet = .moveNote(note)   // 直接切換面板，避免 dismiss 競態
                } label: {
                    Text("移到其他日期")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.accent)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(RoundedRectangle(cornerRadius: 14).fill(pal.accentSoft))
                }
                .buttonStyle(.plain)

                Button {
                    DataOps.delete(note, context)
                    app.showToast("已刪除")
                    dismiss()
                } label: {
                    Text("刪除")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(pal.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(RoundedRectangle(cornerRadius: 14).fill(pal.dangerSoft))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)

            Button {
                save()
            } label: {
                Text("儲存")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(pal.accentInk)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(RoundedRectangle(cornerRadius: 15).fill(pal.accent))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 18)
            .padding(.top, 10)

            Spacer(minLength: 0)
        }
        .animation(.inkQuick, value: selectedDays.isEmpty)
        .presentationBackground(pal.surface)
        .onAppear {
            text = note.text
            if let rid = note.routineUUID,
               let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                var s: Set<Int> = []
                for d in 0..<7 where (r.effectiveMask & (1 << d)) != 0 {
                    s.insert(d)
                }
                selectedDays = s
            } else {
                selectedDays = []
            }
        }
    }

    private func freqChip(_ label: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button {
            action()
            Haptics.light()
        } label: {
            Text(label)
                .font(.system(size: 13.5, weight: .semibold))
                .foregroundStyle(selected ? pal.accentInk : pal.text2)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(RoundedRectangle(cornerRadius: 12).fill(selected ? pal.accent : pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func dayToggle(_ d: Int) -> some View {
        let on = selectedDays.contains(d)
        return Button {
            if on {
                selectedDays.remove(d)
            } else {
                selectedDays.insert(d)
            }
            Haptics.light()
        } label: {
            Text(Day.weekShort[d])
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(on ? pal.accentInk : pal.text2)
                .frame(maxWidth: .infinity)
                .frame(height: 40)
                .background(Circle().fill(on ? pal.accent : pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func save() {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty {
            note.text = t
        }

        if selectedDays.isEmpty {
            // 取消重複：刪除規則並解除所有實例
            if let rid = note.routineUUID {
                if let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                    context.delete(r)
                }
                for n in DataOps.allNotes(context) where n.routineUUID == rid {
                    n.routineUUID = nil
                }
            }
        } else {
            let mask = selectedDays.reduce(0) { $0 | (1 << $1) }
            if let rid = note.routineUUID,
               let r = DataOps.allRoutines(context).first(where: { $0.uuid == rid }) {
                r.daysMask = mask
                r.text = note.text
            } else {
                let r = Routine(text: note.text, daysMask: mask)
                context.insert(r)
                note.routineUUID = r.uuid
            }
        }

        DataOps.save(context)
        app.showToast("已更新")
        dismiss()
    }
}
