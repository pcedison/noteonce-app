import SwiftUI
import SwiftData

/// 雙擊縮小後的「日期卡輪播」：左右滑動快速換日
struct CarouselView: View {
    let app: AppState

    @Environment(\.modelContext) private var context
    @Environment(\.colorScheme) private var scheme

    @State private var dragX: CGFloat = 0
    @State private var animating = false

    private let cardW: CGFloat = 232
    private let gap: CGFloat = 18
    private var step: CGFloat { cardW + gap }
    private let range = 3

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        VStack(spacing: 0) {
            // 頂部：年 / 月 chips
            HStack(spacing: 8) {
                chip(text: "\(String(Day.year(app.carouselDay)))年") {
                    app.sheet = .yearPicker
                }
                chip(text: "\(Day.month(app.carouselDay))月") {
                    app.enterMonth(from: .carousel)
                }
            }
            .padding(.top, 14)

            // 輪播
            GeometryReader { geo in
                let baseX = (geo.size.width - cardW) / 2 - CGFloat(range) * step
                HStack(spacing: gap) {
                    ForEach(-range...range, id: \.self) { off in
                        let day = Day.addDays(app.carouselDay, off)
                        let virtualDist = abs(CGFloat(off) + dragX / step)
                        DayCard(day: day, today: app.today)
                            .frame(width: cardW)
                            .scaleEffect(1 - min(0.16, virtualDist * 0.08))
                            .opacity(1 - min(0.55, Double(virtualDist) * 0.26))
                            .onTapGesture {
                                guard !animating else { return }
                                app.exitCarousel(to: day)
                            }
                    }
                }
                .offset(x: baseX + dragX)
                .frame(height: geo.size.height)
            }
            .contentShape(Rectangle())
            .gesture(swipe)
            .onTapGesture(count: 2) {
                app.exitCarousel(to: app.carouselDay)
            }

            // 底部控制（拇指範圍）
            HStack(spacing: 12) {
                roundNav(icon: "chevron.left") { shift(-1) }
                Button {
                    app.carouselDay = app.today
                    Haptics.light()
                } label: {
                    Text("今天")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(pal.accent)
                        .padding(.horizontal, 20)
                        .frame(height: 44)
                        .background(Capsule().fill(pal.accentSoft))
                }
                .buttonStyle(.plain)
                roundNav(icon: "chevron.right") { shift(1) }
            }
            .padding(.bottom, 6)

            Text("左右滑動換日期 · 點卡片開啟該日 · 雙擊空白處返回")
                .font(.system(size: 12))
                .foregroundStyle(pal.text2)
                .padding(.bottom, 18)
        }
    }

    private func chip(text: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Text(text).font(.system(size: 15.5, weight: .bold))
                Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold)).foregroundStyle(pal.text2)
            }
            .foregroundStyle(pal.text)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(RoundedRectangle(cornerRadius: 12).fill(pal.surface2))
        }
        .buttonStyle(.plain)
    }

    private func roundNav(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(pal.text)
                .frame(width: 44, height: 44)
                .background(Circle().fill(pal.surface2))
        }
        .buttonStyle(.plain)
    }

    // MARK: 手勢

    private var swipe: some Gesture {
        DragGesture(minimumDistance: 5)
            .onChanged { v in
                guard !animating else { return }
                dragX = v.translation.width
            }
            .onEnded { v in
                guard !animating else { return }
                var n = Int((-v.predictedEndTranslation.width / step).rounded())
                n = max(-range, min(range, n))
                settle(to: n)
            }
    }

    private func shift(_ n: Int) {
        guard !animating else { return }
        settle(to: n)
    }

    private func settle(to n: Int) {
        animating = true
        withAnimation(.inkSpring) {
            dragX = -CGFloat(n) * step
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 320_000_000)
            app.carouselDay = Day.addDays(app.carouselDay, n)
            dragX = 0
            animating = false
            if n != 0 { Haptics.light() }
        }
    }
}

/// 單張日期卡（含記事預覽與未實例化的重複項）
struct DayCard: View {
    let day: Date
    let today: Date

    @Environment(\.modelContext) private var context
    @Environment(\.colorScheme) private var scheme

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        let notes = DataOps.notes(on: Day.key(day), context)
        let ghosts = DataOps.ghostRoutines(for: day, today: today, context)
        let total = notes.count + ghosts.count
        let isToday = Day.sameDay(day, today)

        return VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(Day.weekFull[Day.weekdayIndex(day)])
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(pal.text2)
                Spacer()
                if isToday {
                    Text("今天")
                        .font(.system(size: 11.5, weight: .bold))
                        .foregroundStyle(pal.accentInk)
                        .padding(.horizontal, 9).padding(.vertical, 4)
                        .background(RoundedRectangle(cornerRadius: 9).fill(pal.accent))
                }
            }
            Text(Day.mdLabel(day))
                .font(.system(size: 32, weight: .heavy))
                .foregroundStyle(pal.text)
                .padding(.top, 2)
            Text("\(String(Day.year(day)))年")
                .font(.system(size: 12.5))
                .foregroundStyle(pal.text2)

            if total > 0 {
                Text("\(total) 則記事")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(pal.accent)
                    .padding(.horizontal, 9).padding(.vertical, 4)
                    .background(RoundedRectangle(cornerRadius: 9).fill(pal.accentSoft))
                    .padding(.top, 10)

                VStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(notes.prefix(6)), id: \.uuid) { n in
                        previewRow(text: n.text, done: n.done, ghost: false)
                    }
                    ForEach(Array(ghosts.prefix(max(0, 6 - notes.count))), id: \.uuid) { r in
                        previewRow(text: r.text, done: false, ghost: true)
                    }
                }
                .padding(.top, 10)

                if total > 6 {
                    Text("還有 \(total - 6) 則…")
                        .font(.system(size: 11.5))
                        .foregroundStyle(pal.text2)
                        .padding(.top, 4)
                }
            } else {
                Text("沒有記事")
                    .font(.system(size: 12.5))
                    .foregroundStyle(pal.text2)
                    .padding(.top, 16)
            }
            Spacer(minLength: 0)
        }
        .padding(16)
        .frame(height: 446)
        .background(
            RoundedRectangle(cornerRadius: 26)
                .fill(pal.surface)
                .shadow(color: Color.black.opacity(scheme == .dark ? 0.3 : 0.08), radius: 14, y: 6)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 26)
                .strokeBorder(isToday ? pal.accent : pal.surface3.opacity(0.5), lineWidth: isToday ? 1.6 : 1)
        )
    }

    private func previewRow(text: String, done: Bool, ghost: Bool) -> some View {
        HStack(spacing: 8) {
            Circle()
                .fill(done ? pal.accent : Color.clear)
                .overlay(
                    Circle().strokeBorder(
                        done ? pal.accent : pal.text2,
                        style: StrokeStyle(lineWidth: 1.6, dash: ghost ? [2, 2] : [])
                    )
                )
                .frame(width: 8, height: 8)
            Text(text)
                .font(.system(size: 12.5))
                .foregroundStyle(done ? pal.text2 : pal.text)
                .strikethrough(done, color: pal.text2)
                .lineLimit(1)
        }
        .opacity(ghost ? 0.55 : 1)
    }
}
