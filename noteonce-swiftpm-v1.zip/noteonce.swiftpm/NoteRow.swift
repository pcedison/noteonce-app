import SwiftUI

/// 單列記事卡：勾選、點文字編輯、左滑刪除、長按浮起拖曳（拖曳座標回報給父層協調）
struct NoteRow: View {
    @Environment(\.colorScheme) private var scheme

    let note: NoteDisplay
    let isDragSource: Bool
    let isFlashing: Bool
    let onToggle: () -> Void
    let onTapText: () -> Void
    let onDelete: () -> Void
    let onLiftChanged: (CGPoint) -> Void
    let onLiftEnded: () -> Void

    @State private var swipeX: CGFloat = 0
    @State private var swipeOpen = false

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        ZStack(alignment: .trailing) {
            // 底層刪除鈕
            Button(action: {
                withAnimation(.inkQuick) { swipeX = 0; swipeOpen = false }
                onDelete()
            }) {
                Text("刪除")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 82)
                    .frame(maxHeight: .infinity)
                    .background(RoundedRectangle(cornerRadius: 16).fill(pal.danger))
            }
            .buttonStyle(.plain)
            .opacity(swipeOpen || swipeX < -10 ? 1 : 0)

            // 卡片本體
            RowCardContent(note: note, onToggle: onToggle, onTapText: onTapText)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(pal.surface)
                        .shadow(color: Color.black.opacity(scheme == .dark ? 0.30 : 0.07), radius: 10, y: 4)
                )
                .overlay {
                    if isDragSource {
                        RoundedRectangle(cornerRadius: 16)
                            .strokeBorder(pal.text2, style: StrokeStyle(lineWidth: 1.5, dash: [5, 4]))
                    } else if isFlashing {
                        RoundedRectangle(cornerRadius: 16)
                            .strokeBorder(pal.accent, lineWidth: 2)
                    }
                }
                .opacity(isDragSource ? 0.32 : 1)
                .offset(x: swipeX)
                .gesture(swipeGesture)
                .gesture(liftGesture)
        }
    }

    // MARK: 左滑刪除

    private var swipeGesture: some Gesture {
        DragGesture(minimumDistance: 15)
            .onChanged { v in
                guard abs(v.translation.width) > abs(v.translation.height) * 1.3 else { return }
                let base: CGFloat = swipeOpen ? -82 : 0
                swipeX = min(0, max(-96, base + v.translation.width))
            }
            .onEnded { _ in
                withAnimation(.inkQuick) {
                    if swipeX < -44 {
                        swipeX = -82
                        swipeOpen = true
                    } else {
                        swipeX = 0
                        swipeOpen = false
                    }
                }
            }
    }

    // MARK: 長按浮起 → 拖曳

    private var liftGesture: some Gesture {
        LongPressGesture(minimumDuration: 0.3)
            .sequenced(before: DragGesture(minimumDistance: 0, coordinateSpace: .named("dayspace")))
            .onChanged { value in
                switch value {
                case .first(true):
                    break
                case .second(true, let drag):
                    if let d = drag {
                        onLiftChanged(d.location)
                    } else {
                        Haptics.medium()
                    }
                default:
                    break
                }
            }
            .onEnded { _ in
                onLiftEnded()
            }
    }
}

/// 卡片內容（拖曳浮起的殘影也用同一個版型）
struct RowCardContent: View {
    @Environment(\.colorScheme) private var scheme

    let note: NoteDisplay
    var onToggle: (() -> Void)? = nil
    var onTapText: (() -> Void)? = nil

    private var pal: Palette { Palette.of(scheme) }

    var body: some View {
        HStack(spacing: 10) {
            Button(action: {
                Haptics.light()
                onToggle?()
            }) {
                ZStack {
                    Circle()
                        .fill(note.done ? pal.accent : Color.clear)
                        .overlay(Circle().strokeBorder(note.done ? pal.accent : pal.surface3, lineWidth: 2))
                        .frame(width: 25, height: 25)
                    if note.done {
                        Image(systemName: "checkmark")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(pal.accentInk)
                    }
                }
                .frame(width: 42, height: 42)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            HStack(spacing: 7) {
                Text(note.text)
                    .font(.system(size: 16))
                    .foregroundStyle(note.done ? pal.text2 : pal.text)
                    .strikethrough(note.done, color: pal.text2)
                    .lineLimit(3)
                if note.isRoutine {
                    TagChip(text: "重複", icon: "arrow.triangle.2.circlepath", bg: pal.surface2, fg: pal.text2)
                }
                if note.rolled {
                    TagChip(text: "順延", icon: nil, bg: pal.accentSoft, fg: pal.accent)
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
            .onTapGesture {
                onTapText?()
            }
        }
        .padding(.leading, 6)
        .padding(.trailing, 12)
        .padding(.vertical, 7)
        .frame(minHeight: 54)
    }
}

struct TagChip: View {
    let text: String
    let icon: String?
    let bg: Color
    let fg: Color

    var body: some View {
        HStack(spacing: 3) {
            if let icon {
                Image(systemName: icon).font(.system(size: 8, weight: .bold))
            }
            Text(text).font(.system(size: 10.5, weight: .bold))
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 2)
        .background(Capsule().fill(bg))
        .foregroundStyle(fg)
    }
}

/// 傳給列的顯示資料（避免 View 直接依賴 SwiftData 型別細節）
struct NoteDisplay {
    let text: String
    let done: Bool
    let rolled: Bool
    let isRoutine: Bool
}
